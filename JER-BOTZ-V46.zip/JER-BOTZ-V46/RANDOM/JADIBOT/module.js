module.exports = {
modul: {
	baileys: require('@whiskeysockets/baileys'), 
	chalk: require('chalk'),
	boom: require('@hapi/boom'),
	fs: require('fs'),
	figlet: require('figlet'),
	FileType: require('file-type'),
	path: require('path'),
	process: require('process'),
	PhoneNumber: require('awesome-phonenumber')
}
}